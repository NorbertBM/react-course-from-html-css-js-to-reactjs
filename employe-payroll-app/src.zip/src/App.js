import "./App.css";
import Button from "./components/utilities/Button";
import Card from "./components/utilities/Card";
import FormGroup from "./components/utilities/FormGroup";
import Modal from "./components/utilities/Modal";
import Title from "./components/utilities/Title";

function App() {
  return (
    <div className="App">
      <Title />

      {/* <Button /> */}
      {/* <Modal /> */}
      {/* <Card /> */}
      {/* <FormGroup label={"Full name"} /> */}
    </div>
  );
}

export default App;
