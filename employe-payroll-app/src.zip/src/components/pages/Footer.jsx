import React from "react";

export default function Footer() {
  return (
    <footer className="mt-4 text-center">
      {" "}
      <a href="#">v1.01</a>
    </footer>
  );
}
